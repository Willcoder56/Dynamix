#include "vex.h"

using namespace vex;

// ----- Competition control -----
competition Competition;

// ====== CONFIG: CHANGE THESE PORTS TO MATCH YOUR ROBOT ======
motor FL(PORT1, ratio18_1, false); // Front Left   (green)
motor FR(PORT2, ratio18_1, true);  // Front Right  (green)  <-- reversed?
motor BL(PORT3, ratio18_1, false); // Back Left    (green)
motor BR(PORT4, ratio18_1, true);  // Back Right   (green)  <-- reversed?

motor AUX1(PORT5, ratio18_1, false); // Aux motor 1 (L1/L2)
motor AUX2(PORT6, ratio18_1, false); // Aux motor 2 (R1/R2)
motor AUX3(PORT7, ratio18_1, false); // Aux motor 3 (B/DOWN)

controller Controller1(primary);

// ====== DRIVE MODES ======
enum DriveMode {
  FIELD_CENTRIC = 0,
  ROBOT_CENTRIC = 1,
  TANK_DRIVE    = 2
};

int driveMode = FIELD_CENTRIC;

// Fake heading (no IMU)
double estHeadingDeg = 0.0;
double lastTimeSec   = 0.0;

// Max turn speed used for fake heading integration
const double MAX_TURN_DEG_PER_SEC = 180.0;

// Simple deadband
double deadband(double v, double th) {
  return (fabs(v) < th) ? 0.0 : v;
}

// Convert enum -> text
std::string driveModeName() {
  switch (driveMode) {
    case FIELD_CENTRIC: return "FIELD";
    case ROBOT_CENTRIC: return "ROBOT";
    case TANK_DRIVE:    return "TANK";
    default:            return "???";
  }
}

// Update Brain + Controller display
void updateUI() {
  int hdg = static_cast<int>(estHeadingDeg);

  // Controller lines
  Controller1.Screen.clearLine(1);
  Controller1.Screen.clearLine(2);
  Controller1.Screen.clearLine(3);

  Controller1.Screen.setCursor(1, 1);
  Controller1.Screen.print("Mode: %s", driveModeName().c_str());

  Controller1.Screen.setCursor(2, 1);
  Controller1.Screen.print("Hdg: %d", hdg);

  // Brain screen (DYNAMIX + lambda style)
  Brain.Screen.clearScreen();
  Brain.Screen.setCursor(1, 1);
  Brain.Screen.print("  λ   DYNAMIX");
  Brain.Screen.setCursor(2, 1);
  Brain.Screen.print("Mode: %s", driveModeName().c_str());
  Brain.Screen.setCursor(3, 1);
  Brain.Screen.print("Hdg: %d", hdg);
}

// Normalize wheel commands and send to motors
void setDrive(double fl, double fr, double bl, double br) {
  double maxMag = std::max(
    std::max(fabs(fl), fabs(fr)),
    std::max(fabs(bl), fabs(br))
  );

  if (maxMag > 1.0) {
    fl /= maxMag;
    fr /= maxMag;
    bl /= maxMag;
    br /= maxMag;
  }

  FL.spin(fwd, fl * 100.0, percent);
  FR.spin(fwd, fr * 100.0, percent);
  BL.spin(fwd, bl * 100.0, percent);
  BR.spin(fwd, br * 100.0, percent);
}

// ========== PRE-AUTON (default) ==========
void pre_auton(void) {
  vexcodeInit();
  estHeadingDeg = 0.0;
  lastTimeSec = Brain.Timer.system();
  updateUI();
}

// ========== AUTON (EMPTY) ==========
void autonomous(void) {
  // Drive-only version: no auton
}

// ========== DRIVER CONTROL ==========
void usercontrol(void) {
  bool lastX = false;
  bool lastA = false;

  while (1) {
    // ----- Time step -----
    double nowSec = Brain.Timer.system();
    double dt = nowSec - lastTimeSec;
    if (dt <= 0.0) dt = 0.01;
    lastTimeSec = nowSec;

    // ----- Drive mode buttons -----
    bool btnX = Controller1.ButtonX.pressing();
    bool btnA = Controller1.ButtonA.pressing();
    bool btnY = Controller1.ButtonY.pressing();

    if (btnX && !lastX) {
      driveMode = (driveMode + 1) % 3;
    }
    if (btnA && !lastA) {
      driveMode = (driveMode + 3 - 1) % 3; // go backwards through modes
    }

    lastX = btnX;
    lastA = btnA;

    if (btnY) {
      estHeadingDeg = 0.0; // reset fake heading
    }

    // ----- AUX motors -----
    // AUX1: L1 = forward, L2 = reverse
    bool m1Fwd = Controller1.ButtonL1.pressing();
    bool m1Rev = Controller1.ButtonL2.pressing();
    int aux1Power = 0;
    if (m1Fwd && !m1Rev) aux1Power = 100;
    else if (m1Rev && !m1Fwd) aux1Power = -100;
    else aux1Power = 0;
    AUX1.spin(fwd, aux1Power, percent);

    // AUX2: R1 = forward, R2 = reverse
    bool m2Fwd = Controller1.ButtonR1.pressing();
    bool m2Rev = Controller1.ButtonR2.pressing();
    int aux2Power = 0;
    if (m2Fwd && !m2Rev) aux2Power = 100;
    else if (m2Rev && !m2Fwd) aux2Power = -100;
    else aux2Power = 0;
    AUX2.spin(fwd, aux2Power, percent);

    // AUX3: B = forward, DOWN = reverse
    bool m3Fwd = Controller1.ButtonB.pressing();
    bool m3Rev = Controller1.ButtonDown.pressing();
    int aux3Power = 0;
    if (m3Fwd && !m3Rev) aux3Power = 100;
    else if (m3Rev && !m3Fwd) aux3Power = -100;
    else aux3Power = 0;
    AUX3.spin(fwd, aux3Power, percent);

    // ----- Joysticks -----
    // Raw values [-100, 100]
    double Lx = Controller1.Axis4.position(percent) / 100.0; // left stick X
    double Ly = Controller1.Axis3.position(percent) / 100.0; // left stick Y
    double Rx = Controller1.Axis1.position(percent) / 100.0; // right stick X
    double Ry = Controller1.Axis2.position(percent) / 100.0; // right stick Y

    Lx = deadband(Lx, 0.05);
    Ly = deadband(Ly, 0.05);
    Rx = deadband(Rx, 0.05);
    Ry = deadband(Ry, 0.05);

    // ----- Fake heading integration (no IMU) -----
    double rotUnit = 0.0;
    if (driveMode == TANK_DRIVE) {
      rotUnit = deadband((Ry - Ly) / 2.0, 0.05);
    } else {
      rotUnit = Rx;
    }

    double turnRateDegPerSec = rotUnit * MAX_TURN_DEG_PER_SEC;
    estHeadingDeg += turnRateDegPerSec * dt;

    if (estHeadingDeg > 180.0) estHeadingDeg -= 360.0;
    if (estHeadingDeg < -180.0) estHeadingDeg += 360.0;

    updateUI();

    // ----- Drive power -----
    double fl = 0, fr = 0, bl = 0, br = 0;

    if (driveMode == FIELD_CENTRIC) {
      // Field-ish: rotate input by fake heading
      double headingRad = estHeadingDeg * M_PI / 180.0;
      double cosH = cos(headingRad);
      double sinH = sin(headingRad);

      // Driver input (field frame)
      double fx = Lx;
      double fy = Ly;

      double rx =  fx * cosH + fy * sinH;
      double ry = -fx * sinH + fy * cosH;
      double r  = Rx;

      fl =  ry + rx + r;
      fr =  ry - rx - r;
      bl =  ry - rx + r;
      br =  ry + rx - r;

      setDrive(fl, fr, bl, br);

    } else if (driveMode == ROBOT_CENTRIC) {
      double rx = Lx;
      double ry = Ly;
      double r  = Rx;

      fl =  ry + rx + r;
      fr =  ry - rx - r;
      bl =  ry - rx + r;
      br =  ry + rx - r;

      setDrive(fl, fr, bl, br);

    } else if (driveMode == TANK_DRIVE) {
      double left  = Ly;
      double right = Ry;

      fl = left;
      bl = left;
      fr = right;
      br = right;

      setDrive(fl, fr, bl, br);
    }

    wait(20, msec);
  }
}

// ========== MAIN ==========
int main() {
  // Set up callbacks
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run pre-auton
  pre_auton();

  // Keep main alive
  while (true) {
    wait(100, msec);
  }
}
